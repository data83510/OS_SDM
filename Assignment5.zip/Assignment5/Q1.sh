#!/bin/bash

#login name
echo "Your login name is: $LOGNAME"

# home directory
echo "Your home directory is: $HOME"
